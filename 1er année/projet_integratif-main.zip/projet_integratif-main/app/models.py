from django.db import models
import bleach

class Capteur(models.Model):
    capteur_id = models.IntegerField()
    nom = models.CharField()
    piece = models.CharField()
    emplacement = models.TextField()
    
    def dico(self):
        return {"ID du capteur": self.capteur_id, "Nom du capteur": self.nom, "Pièce": self.piece, "Emplacement": self.emplacement}
    
class Data(models.Model):
    data_id = models.IntegerField()
    datetime = models.DateField()
    temperature = models.IntegerField()
    capteur = models.ForeignKey("capteur", on_delete = models.CASCADE, default = None)
    def dico(self):
        return {"ID des Datas": self.data_id, "Date et heure": self.datetime, "Temperature": self.temperature, "ID du capteur": self.capteur}