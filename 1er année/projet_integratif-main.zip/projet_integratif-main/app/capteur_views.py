from django.shortcuts import render, HttpResponseRedirect
from .forms import CapteurForm
from . import models

def create_capteur(request):
    if request.method == "POST":
        form = CapteurForm(request)
        return render(request, "app/capteur/create.html",{"form" : form})
    else:
        form = CapteurForm()
        return render(request, "app/capteur/create.html",{"form" : form})

def traitement_capteur(request):
    lform = CapteurForm(request.POST)
    if lform.is_valid():
        capteur = lform.save()
        return HttpResponseRedirect("/app/index_capteur/")
    else:
        return render(request, "app/capteur/create.html",{"form" : lform})
    
def index_capteur(request):
    liste = list(models.Capteur.objects.all())
    return render(request, "app/capteur/index.html",{"liste" : liste})

def affiche_capteur(request, id):
    capteur = models.Capteur.objects.get(pk = id)
    return render(request, "app/capteur/traitement.html", {"capteur" : capteur})

def update_capteur(request, id):
    capteur = models.Capteur.objects.get(pk=id)
    form = CapteurForm(capteur.dico())
    return render(request, "app/capteur/update.html",{"form": form, "id" : id})

def updatetraitement_capteur(request, id):
    lform = CapteurForm(request.POST)
    if lform.is_valid():
        capteur = lform.save(commit = False)
        capteur.id = id
        capteur.save()
        return HttpResponseRedirect("/app/index_capteur/")
    else:
        return render(request, "app/capteur/update.html",{"form" : lform, "id" : id})

def delete_capteur(request, id):
    capteur = models.Capteur.objects.get(pk = id)
    capteur.delete()
    return HttpResponseRedirect("/app/")



