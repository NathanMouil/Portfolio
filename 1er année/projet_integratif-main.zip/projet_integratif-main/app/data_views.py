from django.shortcuts import render, HttpResponseRedirect
from .forms import DataForm
from . import models

def create_data(request):
    if request.method == "POST":
        form = DataForm(request)
        return render(request, "app/data/create.html",{"form" : form})
    else:
        form = DataForm()
        return render(request, "app/data/create.html",{"form" : form})

def traitement_data(request):
    lform = DataForm(request.POST)
    if lform.is_valid():
        data = lform.save()
        return HttpResponseRedirect("/app/")
    else:
        return render(request, "app/data/create.html",{"form" : lform})
    
def index_data(request):
    liste = list(models.Data.objects.all())
    return render(request, "app/data/index.html",{"liste" : liste})

def affiche_data(request, id):
    data = models.Data.objects.get(pk = id)
    return render(request, "app/data/traitement.html", {"data" : data})

def update_data(request, id):
    data = models.Data.objects.get(pk=id)
    form = DataForm(data.dico())
    return render(request, "app/data/update.html",{"form": form, "id" : id})

def updatetraitement_data(request, id):
    lform = DataForm(request.POST)
    if lform.is_valid():
        data = lform.save(commit = False)
        data.id = id
        data.save()
        return HttpResponseRedirect("/app/")
    else:
        return render(request, "app/data/update.html",{"form" : lform, "id" : id})

def delete_data(request, id):
    data = models.Data.objects.get(pk = id)
    data.delete()
    return HttpResponseRedirect("/app/")



