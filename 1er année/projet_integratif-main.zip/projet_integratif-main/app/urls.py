from django.urls import path
from . import capteur_views, data_views

urlpatterns=[
    # page pour les capteurs
    path("create_capteur/", capteur_views.create_capteur),
    path("traitement_capteur/", capteur_views.traitement_capteur),
    path("index_capteur/", capteur_views.index_capteur),
    path("affiche_capteur/<int:id>/", capteur_views.affiche_capteur),
    path("update_capteur/<int:id>/", capteur_views.update_capteur),
    path("updatetraitement_capteur/<int:id>/", capteur_views.updatetraitement_capteur),
    path("delete_capteur/<int:id>/", capteur_views.delete_capteur),
    # page pour les données
    path("create_data/", data_views.create_data),
    path("traitement_data/",data_views.traitement_data),
    path("", data_views.index_data),
    path("affiche_data/<int:id>/", data_views.affiche_data),
    path("update_data/<int:id>/", data_views.update_data),
    path("updatetraitement_data/<int:id>/", data_views.updatetraitement_data),
    path("delete_data/<int:id>/", data_views.delete_data),
]