from django.forms import ModelForm
from django.utils.translation import gettext_lazy as _
from . import models

class CapteurForm(ModelForm):
    class Meta :
        model = models.Capteur
        fields = ('capteur_id', 'nom', 'piece', 'emplacement')
        labels = {
            'capteur_id' : _('ID du capteur'),
            'nom' : _('Nom du capteur'),
            'piece' : _('Pièce du capteur'),
            'emplacement' : _('Emplacement du capteur'),
        }

class DataForm(ModelForm):
    class Meta :
        model = models.Data
        fields = ('data_id', 'datetime', 'temperature', 'capteur')
        labels = {
            'data_id' : _('ID des données'),
            'datetime' : _('Date et heure des données'),
            'temperature' : _('Temperature'),
            'capteur' : _("ID du capteur"),
        }