const Database = require('better-sqlite3');

const {
    creerSignalement,
    obtenirSignalement,
    obtenirSignalements,
    modifierStatutSignalement
} = require('../src/services/reportService');

describe('Système de signalement', () => {
    let db;

    beforeEach(() => {
        db = new Database(':memory:');

        db.exec(`
            CREATE TABLE Utilisateur (
                idUser INTEGER PRIMARY KEY
            );

            CREATE TABLE Publication (
                idPubli INTEGER PRIMARY KEY,
                idUser INTEGER NOT NULL
            );

            CREATE TABLE Commentaire (
                idComm INTEGER PRIMARY KEY,
                idUser INTEGER NOT NULL,
                idPubli INTEGER NOT NULL,
                contenuCom TEXT NOT NULL
            );

            CREATE TABLE Media (
                idMedia INTEGER PRIMARY KEY,
                idPubli INTEGER,
                nomMedia TEXT NOT NULL,
                typeMedia TEXT NOT NULL,
                duree INTEGER,
                dateUpload DATETIME DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE Conversation (
                idConversation INTEGER PRIMARY KEY
            );

            CREATE TABLE ConversationMembre (
                idConversation INTEGER NOT NULL,
                idUser INTEGER NOT NULL,
                PRIMARY KEY (idConversation, idUser)
            );

            CREATE TABLE Message (
                idMessage INTEGER PRIMARY KEY,
                idConversation INTEGER NOT NULL,
                idUser INTEGER NOT NULL,
                contenu TEXT NOT NULL
            );

            CREATE TABLE Signalement (
                idSignalement INTEGER PRIMARY KEY AUTOINCREMENT,
                idUserAuteur INTEGER NOT NULL,
                typeContenu TEXT CHECK(
                    typeContenu IN (
                        'publication',
                        'commentaire',
                        'utilisateur',
                        'media',
                        'message'
                    )
                ) NOT NULL,
                idContenu INTEGER NOT NULL,
                motif TEXT NOT NULL,
                dateSignalement DATETIME DEFAULT CURRENT_TIMESTAMP,
                statut TEXT CHECK(
                    statut IN (
                        'en_attente',
                        'traite',
                        'rejete'
                    )
                ) DEFAULT 'en_attente',
                FOREIGN KEY (idUserAuteur)
                    REFERENCES Utilisateur(idUser)
                    ON DELETE CASCADE
            );

            INSERT INTO Utilisateur (idUser)
            VALUES (1), (2);

            INSERT INTO Publication (idPubli, idUser)
            VALUES (10, 1);
        `);

        db.prepare(`
            INSERT INTO Media (
                idMedia,
                idPubli,
                nomMedia,
                typeMedia
            )
            VALUES (?, ?, ?, ?)
        `).run(1, 10, 'photo-test.jpg', 'image');

        db.prepare(`
            INSERT INTO Commentaire (
                idComm,
                idUser,
                idPubli,
                contenuCom
            )
            VALUES (?, ?, ?, ?)
        `).run(1, 1, 10, 'Commentaire de test');

        db.exec(`
            INSERT INTO Conversation (idConversation) VALUES (100);
            INSERT INTO ConversationMembre (idConversation, idUser) VALUES (100, 1), (100, 2);
        `);

        db.prepare(`
            INSERT INTO Message (idMessage, idConversation, idUser, contenu)
            VALUES (?, ?, ?, ?)
        `).run(1, 100, 1, 'Message privé de test');
    });

    afterEach(() => {
        db.close();
    });

    test('Un utilisateur peut créer un signalement', () => {
        const resultat = creerSignalement(
            db,
            1,
            'publication',
            10,
            'Contenu inapproprié'
        );

        expect(resultat.succes).toBe(true);
        expect(resultat.idSignalement).toBe(1);
    });

    test('Le signalement est enregistré avec le statut en_attente', () => {
        const resultat = creerSignalement(
            db,
            1,
            'publication',
            10,
            'Contenu inapproprié'
        );

        const signalement = obtenirSignalement(
            db,
            resultat.idSignalement
        );

        expect(signalement.statut).toBe('en_attente');
        expect(signalement.motif).toBe('Contenu inapproprié');
    });

    test('Un type de contenu invalide est refusé', () => {
        const resultat = creerSignalement(
            db,
            1,
            'contenu_invalide',
            10,
            'Test'
        );

        expect(resultat.succes).toBe(false);
        expect(resultat.erreur).toBe('Type de contenu invalide');
    });

    test('Un motif vide est refusé', () => {
        const resultat = creerSignalement(
            db,
            1,
            'publication',
            10,
            '   '
        );

        expect(resultat.succes).toBe(false);
        expect(resultat.erreur).toBe('Le motif est obligatoire');
    });

    test('Un utilisateur inexistant ne peut pas créer de signalement', () => {
        const resultat = creerSignalement(
            db,
            999,
            'publication',
            10,
            'Test'
        );

        expect(resultat.succes).toBe(false);
        expect(resultat.erreur).toBe('Utilisateur introuvable');
    });

    test('Un identifiant de contenu invalide est refusé', () => {
        const resultat = creerSignalement(
            db,
            1,
            'publication',
            0,
            'Test'
        );

        expect(resultat.succes).toBe(false);
        expect(resultat.erreur).toBe('Identifiant du contenu invalide');
    });

    test('Les signalements peuvent être récupérés', () => {
        creerSignalement(db, 1, 'publication', 10, 'Premier signalement');
        creerSignalement(db, 2, 'commentaire', 1, 'Deuxième signalement');

        const signalements = obtenirSignalements(db);
        expect(signalements).toHaveLength(2);
    });

    test('Un utilisateur ne voit pas un signalement qui le concerne', () => {
        creerSignalement(db, 2, 'publication', 10, 'Signalement concernant l’utilisateur 1');

        testPublicationId20 = db.prepare(`
            INSERT INTO Publication (idPubli, idUser)
            VALUES (?, ?)
        `).run(20, 2);

        creerSignalement(db, 2, 'publication', 20, 'Signalement concernant l’utilisateur 2');

        const signalements = obtenirSignalements(db, 1);
        expect(signalements).toHaveLength(1);
        expect(signalements[0].idContenu).toBe(20);
    });

    test('Un signalement inexistant retourne null', () => {
        const signalement = obtenirSignalement(db, 999);
        expect(signalement).toBeNull();
    });

    test('Un utilisateur peut signaler un commentaire', () => {
        const resultat = creerSignalement(db, 1, 'commentaire', 1, 'Commentaire inapproprié');
        expect(resultat.succes).toBe(true);

        const signalement = db.prepare(`
            SELECT * FROM Signalement WHERE idSignalement = ?
        `).get(resultat.idSignalement);

        expect(signalement.typeContenu).toBe('commentaire');
        expect(signalement.idContenu).toBe(1);
        expect(signalement.statut).toBe('en_attente');
    });

    test('Un commentaire inexistant ne peut pas être signalé', () => {
        const resultat = creerSignalement(db, 1, 'commentaire', 9999, 'Commentaire inapproprié');
        expect(resultat.succes).toBe(false);
        expect(resultat.erreur).toBe('Commentaire introuvable');
    });

    test('Un utilisateur inexistant ne peut pas être signalé', () => {
        const resultat = creerSignalement(db, 1, 'utilisateur', 999, 'Utilisateur problématique');
        expect(resultat.succes).toBe(false);
        expect(resultat.erreur).toBe('Utilisateur introuvable');
    });

    test('Un média inexistant ne peut pas être signalé', () => {
        const resultat = creerSignalement(db, 1, 'media', 999, 'Média problématique');
        expect(resultat.succes).toBe(false);
        expect(resultat.erreur).toBe('Media introuvable');
    });

    test('Un motif de plus de 500 caractères est refusé', () => {
        const motifTropLong = 'a'.repeat(501);
        const resultat = creerSignalement(db, 1, 'publication', 10, motifTropLong);
        expect(resultat.succes).toBe(false);
        expect(resultat.erreur).toBe('Le motif ne doit pas dépasser 500 caractères');
    });

    test('Un utilisateur ne peut pas signaler deux fois le même contenu', () => {
        const premierSignalement = creerSignalement(db, 1, 'publication', 10, 'Premier signalement');
        expect(premierSignalement.succes).toBe(true);

        const deuxiemeSignalement = creerSignalement(db, 1, 'publication', 10, 'Deuxième signalement');
        expect(deuxiemeSignalement.succes).toBe(false);
        expect(deuxiemeSignalement.erreur).toBe('Ce contenu a déjà été signalé par cet utilisateur');
    });

    test('Deux utilisateurs différents peuvent signaler le même contenu', () => {
        const premierSignalement = creerSignalement(db, 1, 'publication', 10, 'Premier signalement');
        const deuxiemeSignalement = creerSignalement(db, 2, 'publication', 10, 'Deuxième signalement');

        expect(premierSignalement.succes).toBe(true);
        expect(deuxiemeSignalement.succes).toBe(true);
    });

    test('Un utilisateur ne peut pas traiter un signalement qui le concerne', () => {
        const resultatCreation = creerSignalement(db, 2, 'publication', 10, 'Signalement concernant l’utilisateur 1');

        const resultat = modifierStatutSignalement(
            db,
            resultatCreation.idSignalement,
            'traite',
            1
        );

        expect(resultat.succes).toBe(false);
        expect(resultat.code).toBe(403);
        expect(resultat.erreur).toBe('Vous ne pouvez pas traiter un signalement qui vous concerne');

        const signalement = db.prepare(`
            SELECT statut FROM Signalement WHERE idSignalement = ?
        `).get(resultatCreation.idSignalement);

        expect(signalement.statut).toBe('en_attente');
    });

    test('Un membre de la conversation peut signaler un message', () => {
        const resultat = creerSignalement(db, 2, 'message', 1, 'Message inapproprié');
        expect(resultat.succes).toBe(true);
    });

    test('Un utilisateur qui n’est pas membre de la conversation ne peut pas signaler un message', () => {
        db.prepare(`
            INSERT INTO Utilisateur (idUser) VALUES (?)
        `).run(3);

        const resultat = creerSignalement(db, 3, 'message', 1, 'Tentative de fuite de contenu privé');

        expect(resultat.succes).toBe(false);
        expect(resultat.erreur).toBe(
            'Vous ne pouvez signaler que les messages de vos propres conversations'
        );
    });
});