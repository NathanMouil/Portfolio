require('dotenv').config();

const express = require('express');
const path = require('path');
const fs = require('fs/promises');
const cookieParser = require('cookie-parser');
const jwt = require('jsonwebtoken');

// Imports des routes et services
const authRoutes = require('./routes/authRoutes');
const postRoutes = require('./routes/postRoutes');
const publicationRoutes = require('./routes/publicationRoutes');
const commentRoutes = require('./routes/commentRoutes');
const friendshipRoutes = require('./routes/friendshipRoutes');
const profileRoutes = require('./routes/profileRoutes');
const userRoutes = require('./routes/userRoutes');
const searchRoutes = require('./routes/searchRoutes');
const reportRoutes = require('./routes/reportRoutes');
const adminRoutes = require('./routes/adminRoutes');
const conversationRoutes = require('./routes/conversationRoutes');
const messageRoutes = require('./routes/messageRoutes');
const blockRoutes = require('./routes/blockRoutes');
const notificationRoutes = require('./routes/notificationRoutes');
const notificationService = require('./services/notificationService');
const commentController = require('./controllers/commentController');
const authMiddleware = require('./middlewares/authMiddleware');
const adminOrModeratorMiddleware = require('./middlewares/adminOrModeratorMiddleware');
const superAdminMiddleware = require('./middlewares/superAdminMiddleware');
const profileService = require('./services/profileService');
const friendshipModel = require('./models/friendshipModel');
const conversationService = require('./services/conversationService');
const messageService = require('./services/messageService');
const postService = require('./services/postService');
const blockService = require('./services/blockService');
const db = require('./config/database');
const { linkifyHashtags } = require('./utils/hashtagUtils');

const app = express();

// 1. Moteur de templates EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../views'));

// 2. Middlewares globaux
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, '../public')));

// 3. Routes d'affichage des pages (Front)

app.get('/', (req, res) => {
  res.render('login');
});

app.get('/login', (req, res) => {
  res.render('login');
});

// Page pour les comptes sanctionnés
app.get('/banned', (req, res) => {
  const statut = req.query.statut || 'suspendu';
  res.render('banned', { statut });
});

// Fil d'actualité
app.get('/home', authMiddleware, (req, res) => {
  try {
    const publications = postService.getFeedForUser(req.user.idUser);

    const suggestions = db.prepare(`
      SELECT u.idUser, u.pseudo, u.role, p.bio
      FROM Utilisateur u
      LEFT JOIN Profil p ON u.idUser = p.idUser
      WHERE u.idUser != ?
        AND u.idUser NOT IN (
          SELECT idUserBloque FROM Blocage WHERE idUserBloqueur = ?
          UNION
          SELECT idUserBloqueur FROM Blocage WHERE idUserBloque = ?
        )
      LIMIT 10
    `).all(req.user.idUser, req.user.idUser, req.user.idUser);

    res.render('feed', {
      user: req.user,
      publications,
      suggestions,
      linkifyHashtags
    });
  } catch (err) {
    console.error('Erreur GET /home :', err);
    res.render('feed', {
      user: req.user,
      publications: [],
      suggestions: [],
      linkifyHashtags
    });
  }
});

// Panel d'administration & modération
app.get('/admin', authMiddleware, adminOrModeratorMiddleware, (req, res) => {
  try {
    res.render('admin', { user: req.user });
  } catch (err) {
    console.error('Erreur GET /admin :', err);
    res.redirect('/home');
  }
});

// Panel Super Admin (protégé par le middleware basé sur le .env)
app.get('/super-admin', authMiddleware, superAdminMiddleware, (req, res) => {
  try {
    res.render('admin', { user: { ...req.user, role: 'superadmin' } });
  } catch (err) {
    console.error('Erreur GET /super-admin :', err);
    res.redirect('/home');
  }
});

// Messagerie
app.get('/messages', authMiddleware, async (req, res) => {
  try {
    const conversations = await conversationService.getMyConversations(req.user.idUser);
    res.render('messages', {
      user: req.user,
      conversations: conversations || [],
      activeTab: 'messages'
    });
  } catch (err) {
    console.error('Erreur GET /messages :', err);
    res.render('messages', {
      user: req.user,
      conversations: [],
      activeTab: 'messages'
    });
  }
});

app.get('/messages/:idConversation', authMiddleware, async (req, res) => {
  try {
    const idConversation = Number(req.params.idConversation);

    if (!Number.isInteger(idConversation) || idConversation <= 0) {
      return res.redirect('/messages');
    }

    const messages = await messageService.getMessages(idConversation, req.user.idUser);
    await messageService.markAsRead(idConversation, req.user.idUser);

    const membres = await conversationService.getConversationMembers(idConversation, req.user.idUser);
    const conversations = await conversationService.getMyConversations(req.user.idUser);
    const conv = conversations ? conversations.find(c => c.idConversation === idConversation) : null;

    const estCreateurCourant = (membres || []).some(
      (m) => m.idUser === req.user.idUser && !!m.estCreateur
    );

    res.render('conversation', {
      idConversation,
      titreConversation: conv ? (conv.titreGroupe || conv.autrePseudo || 'Discussion') : 'Discussion',
      estGroupe: !!(conv && conv.titreGroupe),
      estCreateurCourant,
      membres: membres || [],
      messages: messages || [],
      idUserCourant: req.user.idUser,
      user: req.user,
      activeTab: 'messages'
    });
  } catch (err) {
    console.error('Erreur GET /messages/:idConversation :', err);
    res.redirect('/messages');
  }
});

// Notifications
app.get('/notifications', authMiddleware, async (req, res) => {
  try {
    const notifications = await notificationService.getMyNotifications(req.user.idUser);
    // On marque tout comme lu APRÈS avoir récupéré la liste,
    // pour que les non lues restent mises en évidence à cet affichage
    await notificationService.markAllAsRead(req.user.idUser);

    res.render('notification', {
      user: req.user,
      notifications,
      activeTab: 'notifications'
    });
  } catch (err) {
    console.error('Erreur GET /notifications :', err);
    res.render('notification', {
      user: req.user,
      notifications: [],
      activeTab: 'notifications'
    });
  }
});

// Mon profil
app.get('/profile', authMiddleware, async (req, res) => {
  try {
    const profile = await profileService.getMyProfile(req.user.idUser);

    const stats = {
      nbAbonnes: friendshipModel.listerAbonnes(db, req.user.idUser).length,
      nbAbonnements: friendshipModel.listerAbonnements(db, req.user.idUser).length,
      nbAmis: friendshipModel.listerAmis(db, req.user.idUser).length
    };

    res.render('profile', {
      profile,
      isOwner: true,
      estAbonne: false,
      sontAmis: false,
      jeLuiBloque: false,
      ilMeBloque: false,
      stats,
      user: req.user,
      linkifyHashtags
    });
  } catch (err) {
    console.error('Erreur GET /profile :', err);
    res.status(500).send('Erreur lors du chargement de votre profil.');
  }
});

// Paramètres
app.get('/settings', authMiddleware, (req, res) => {
  try {
    const user = db.prepare(`
      SELECT idUser, pseudo, email, dateNaissance, role, statut
      FROM Utilisateur
      WHERE idUser = ?
    `).get(req.user.idUser);

    if (!user) {
      return res.redirect('/login');
    }

    res.render('settings', {
      user,
      title: 'Paramètres'
    });
  } catch (err) {
    console.error('Erreur GET /settings :', err);
    res.redirect('/profile');
  }
});

// Publications (Pages Web)
app.get('/publication/create', authMiddleware, (req, res) => {
  res.render('posts', { user: req.user });
});

app.get('/publication/:idPubli', authMiddleware, commentController.renderPostPage);

// Profil édition
app.get('/profile/edit', authMiddleware, async (req, res) => {
  try {
    const profile = await profileService.getMyProfile(req.user.idUser);
    res.render('editProfile', { profile });
  } catch (err) {
    console.error('Erreur GET /profile/edit :', err);
    res.redirect('/profile');
  }
});

app.post('/profile/edit', authMiddleware, async (req, res) => {
  try {
    const { prenom, nom, bio } = req.body;
    await profileService.updateMyProfile(req.user.idUser, { prenom, nom, bio });
    res.redirect('/profile');
  } catch (err) {
    console.error('Erreur POST /profile/edit :', err);
    const profile = await profileService.getMyProfile(req.user.idUser);
    res.render('editProfile', {
      profile: { ...profile, ...req.body },
      error: err.message
    });
  }
});

// Profil public
app.get('/profile/:pseudo', authMiddleware, async (req, res) => {
  try {
    const targetProfile = await profileService.getPublicProfile(
      req.params.pseudo,
      req.user.idUser
    );

    const isOwner = req.user.idUser === targetProfile.idUser;
    let estAbonne = false;
    let sontAmis = false;
    let jeLuiBloque = false;
    let ilMeBloque = false;

    if (!isOwner) {
      const blockStatus = blockService.estBloque(req.user.idUser, targetProfile.idUser, db);
      jeLuiBloque = blockStatus.jeLuiBloque;
      ilMeBloque = blockStatus.ilMeBloque;

      const dejaAbonne = db.prepare(`
        SELECT 1
        FROM Abonnement
        WHERE idUserAbonne = ? AND idUserSuivi = ?
      `).get(req.user.idUser, targetProfile.idUser);

      estAbonne = !!dejaAbonne;
      sontAmis = friendshipModel.sontAmis(db, req.user.idUser, targetProfile.idUser);
    }

    const stats = {
      nbAbonnes: friendshipModel.listerAbonnes(db, targetProfile.idUser).length,
      nbAbonnements: friendshipModel.listerAbonnements(db, targetProfile.idUser).length,
      nbAmis: friendshipModel.listerAmis(db, targetProfile.idUser).length
    };

    res.render('profile', {
      profile: targetProfile,
      isOwner,
      estAbonne,
      sontAmis,
      jeLuiBloque,
      ilMeBloque,
      stats,
      user: req.user,
      linkifyHashtags
    });
  } catch (err) {
    console.error(`Erreur GET /profile/${req.params.pseudo} :`, err.message);
    res.redirect('/home');
  }
});

app.use('/search', searchRoutes);

// Uploads
app.get('/uploads/:filename', async (req, res) => {
  try {
    const filename = req.params.filename;

    if (filename !== path.basename(filename)) {
      return res.status(400).send('Nom de fichier invalide.');
    }

    const contentTypes = {
      '.jpg': 'image/jpeg',
      '.jpeg': 'image/jpeg',
      '.png': 'image/png',
      '.webp': 'image/webp',
      '.mp4': 'video/mp4',
      '.webm': 'video/webm',
      '.ogg': 'video/ogg',
      '.mov': 'video/quicktime'
    };

    const extension = path.extname(filename).toLowerCase();
    const contentType = contentTypes[extension];

    if (!contentType) {
      return res.status(404).send('Fichier non trouvé.');
    }

    const filePath = path.join(__dirname, '../uploads', filename);

    try {
      await fs.access(filePath);
    } catch {
      return res.status(404).send('Fichier non trouvé.');
    }

    res.set('X-Content-Type-Options', 'nosniff');
    res.type(contentType);

    return res.sendFile(path.resolve(filePath));
  } catch (error) {
    console.error('Erreur accès média :', error);
    return res.status(500).send('Erreur lors de la récupération du fichier.');
  }
});

// 4. Routes API (Back)
app.use('/api/auth', authRoutes);
app.use('/api/publications', postRoutes);
app.use('/api/publications', publicationRoutes);
app.use('/api/friendships', friendshipRoutes);
app.use('/api/profile', profileRoutes);
app.use('/api/comments', commentRoutes);
app.use('/api/user', userRoutes);
app.use('/api/conversations', conversationRoutes);
app.use('/api/conversations', messageRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/blocks', blockRoutes);

// Routes Signalement & Modération
if (reportRoutes) app.use('/api/signalements', reportRoutes);
if (adminRoutes) app.use('/api/admin', adminRoutes);

module.exports = app;