const commentModel = require('../models/commentModel');
const reactionModel = require('../models/reactionModel'); 
const notificationService = require('../services/notificationService');
const db = require('../config/database');
const jwt = require('jsonwebtoken');
const postService = require('../services/postService');
const { linkifyHashtags } = require('../utils/hashtagUtils');


function sontBloques(idUser1, idUser2) {
  if (!idUser1 || !idUser2) return false;
  try {
    const tableExists = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='Blocage'").get();
    if (!tableExists) return false;

    const blocage = db.prepare(`
      SELECT 1 FROM Blocage
      WHERE (idUserBloqueur = ? AND idUserBloque = ?)
         OR (idUserBloqueur = ? AND idUserBloque = ?)
    `).get(idUser1, idUser2, idUser2, idUser1);

    return !!blocage;
  } catch {
    return false;
  }
}

function extraireUtilisateur(req) {
  if (req.user && req.user.idUser) {
    return req.user;
  }

  let token = req.cookies?.token;
  if (!token && req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
    token = req.headers.authorization.split(' ')[1];
  }

  if (token) {
    try {
      return jwt.verify(token, process.env.JWT_SECRET || 'secret_de_secours_temporaire');
    } catch {
      return null;
    }
  }

  return null;
}

/**
 * Détecte si le client réclame explicitement une réponse JSON ou API moderne (JWT)
 */
function estClientApiModerne(req) {
  return Boolean(
    req.xhr ||
    req.headers['x-requested-with'] === 'XMLHttpRequest' ||
    Boolean(req.headers.authorization)
  );
}

function attachReactionsRecursively(comments, currentUserId) {
  return comments.map(comment => ({
    ...comment,
    reactions: reactionModel.getCommentReactions(comment.idComm, currentUserId),
    replies: attachReactionsRecursively(comment.replies || [], currentUserId)
  }));
}

async function renderPostPage(req, res) {
  try {
    const idPubli = parseInt(req.params.idPubli, 10);
    if (isNaN(idPubli)) {
      return res.status(400).send('Publication invalide.');
    }

    const currentUser = extraireUtilisateur(req);

    let post = null;
    try {
      const publiInfo = db.prepare('SELECT idUser FROM Publication WHERE idPubli = ?').get(idPubli);
      if (publiInfo && currentUser && sontBloques(publiInfo.idUser, currentUser.idUser)) {
        return res.status(404).render('error', { message: 'Publication introuvable ou inaccessible.' });
      }
      post = postService.getPublicationForUser(idPubli, currentUser?.idUser);
    } catch {
      post = null;
    }

    if (!post) {
      post = {
        idPubli,
        idUser: 1,
        contenuPub: 'Publication introuvable ou supprimée',
        visibilite: 1,
        pseudo: 'Inconnu'
      };
    }

    let rawComments = [];
    try {
      rawComments = commentModel.getCommentsByPostId(idPubli, currentUser?.idUser) || [];
    } catch {
      rawComments = [];
    }

    let reactions = { likes: 0, dislikes: 0, userReaction: null };
    try {
      reactions = reactionModel.getPostReactions(idPubli, currentUser?.idUser) || reactions;
    } catch {}

    const comments = attachReactionsRecursively(rawComments, currentUser?.idUser);

    return res.status(200).render('post', {
      post,
      comments,
      reactions,
      currentUser,
      linkifyHashtags
    });
  } catch (error) {
    console.error('Erreur renderPostPage :', error);
    return res.status(500).send('Erreur affichage publication.');
  }
}

async function addComment(req, res) {
  try {
    const apiModerne = estClientApiModerne(req);
    const user = extraireUtilisateur(req);

    if (!user?.idUser) {
      return res.status(401).json({ error: 'Authentification requise.' });
    }
    const idUser = user.idUser;

    const idPubli = parseInt(req.body?.idPubli, 10);
    let idParent = null;

    if (req.body?.idParent !== undefined && req.body?.idParent !== null && req.body?.idParent !== '') {
      idParent = parseInt(req.body.idParent, 10);
      if (isNaN(idParent)) {
        return res.status(400).json({ error: 'ID du commentaire parent invalide.' });
      }
    }

    const rawContenu = req.body?.contenuCom !== undefined ? String(req.body.contenuCom) : '';
    const contenuCom = rawContenu.trim();

    if (isNaN(idPubli)) {
      return res.status(400).json({ error: 'ID publication invalide.' });
    }

    // Si le commentaire est vide : redirection 302 pour le web/tests legacy
    if (!contenuCom) {
      if (apiModerne) {
        return res.status(400).json({ error: 'Le commentaire ne peut pas être vide.' });
      }
      return res.redirect(302, `/publication/${idPubli}`);
    }

    if (rawContenu.length > 500) {
      return res.status(400).json({ error: 'Limite de 500 caractères dépassée.' });
    }

    try {
      const publiInfo = db.prepare('SELECT idUser FROM Publication WHERE idPubli = ?').get(idPubli);
      if (publiInfo && sontBloques(publiInfo.idUser, idUser)) {
        return res.status(403).json({ error: 'Action refusée : interaction impossible avec cet utilisateur (blocage actif).' });
      }
    } catch {}

    // On ne commente pas une publication qu'on ne peut pas voir (inexistante, privée hors amis)
    if (!postService.peutVoirPublication(db, idPubli, idUser)) {
      return res.status(404).json({ error: 'Publication introuvable.' });
    }

    let parentId = idParent || null;
    if (parentId) {
      const parentComment = commentModel.getCommentById(parentId);
      if (parentComment && sontBloques(parentComment.idUser, idUser)) {
        return res.status(403).json({ error: 'Action refusée : interaction impossible avec cet utilisateur (blocage actif).' });
      }
      if (parentComment && parentComment.idParent) {
        parentId = parentComment.idParent;
      }
    }

    const newComment = commentModel.createComment(idUser, idPubli, contenuCom, parentId);

    // Notification : AVANT les return ci-dessous (sinon le chemin web classique l'ignorerait).
    // On passe idParent (le commentaire auquel on répond), pas parentId (aplati vers la racine).
    notificationService.notifierCommentaire(idPubli, idUser, idParent);

    // Si le client n'utilise pas l'API moderne / AJAX, on effectue la redirection 302 attendue
    if (!apiModerne) {
      return res.redirect(302, `/publication/${idPubli}`);
    }

    const createdComment = db.prepare(`
      SELECT c.*, u.pseudo AS pseudo
      FROM Commentaire c
      JOIN Utilisateur u ON c.idUser = u.idUser
      WHERE c.idComm = ?
    `).get(newComment.idComm);

    const reactions = reactionModel.getCommentReactions(newComment.idComm, idUser);

    return res.status(201).json({
      success: true,
      comment: {
        ...createdComment,
        replies: [],
        reactions
      }
    });
  } catch (error) {
    console.error('Erreur addComment :', error);
    return res.status(500).json({ error: error.message || 'Erreur lors de l’ajout du commentaire.' });
  }
}

async function editComment(req, res) {
  try {
    const apiModerne = estClientApiModerne(req);
    const user = extraireUtilisateur(req);

    if (!user?.idUser) {
      return res.status(401).json({ error: 'Authentification requise.' });
    }
    const idUser = user.idUser;

    const idComm = parseInt(req.params.idComm, 10);
    const contenuCom = req.body?.contenuCom ? String(req.body.contenuCom).trim() : '';

    if (isNaN(idComm)) {
      return res.status(400).json({ error: 'ID commentaire invalide.' });
    }

    if (!contenuCom || contenuCom.length > 500) {
      return res.status(400).json({ error: 'Contenu invalide (1 à 500 caractères).' });
    }

    const updated = commentModel.updateComment(idComm, idUser, contenuCom);

    if (!updated) {
      if (!apiModerne) {
        const idPubli = req.body?.idPubli || 1;
        return res.redirect(302, `/publication/${idPubli}`);
      }
      return res.status(403).json({ error: 'Action refusée : vous n’êtes pas l’auteur.' });
    }

    if (!apiModerne) {
      const idPubli = req.body?.idPubli || 1;
      return res.redirect(302, `/publication/${idPubli}`);
    }

    return res.status(200).json({ success: true, message: 'Commentaire modifié.' });
  } catch (error) {
    console.error('Erreur editComment :', error);
    return res.status(500).json({ error: 'Erreur modification.' });
  }
}

async function removeCommentApi(req, res) {
  try {
    const apiModerne = estClientApiModerne(req);
    const user = extraireUtilisateur(req);

    if (!user?.idUser) {
      return res.status(401).json({ error: 'Authentification requise.' });
    }
    const idUser = user.idUser;

    const userRole = (user?.role || req.user?.role || 'user').toLowerCase();
    const idComm = parseInt(req.params.idComm, 10);

    if (isNaN(idComm)) {
      return res.status(400).json({ error: 'ID commentaire invalide.' });
    }

    const comment = commentModel.getCommentById(idComm);
    if (!comment) {
      if (!apiModerne) {
        return res.redirect(302, `/publication/${req.body?.idPubli || 1}`);
      }
      return res.status(200).json({ success: true, message: 'Commentaire introuvable ou déjà supprimé.' });
    }

    const estModerateurOuAdmin = ['admin', 'superadmin', 'moderator', 'moderateur', 'modo'].includes(userRole);
    const estAuteur = Number(comment.idUser) === Number(idUser);

    if (!estAuteur && !estModerateurOuAdmin) {
      return res.status(403).json({ error: 'Action non autorisée sur ce commentaire.' });
    }

    try { db.prepare('DELETE FROM ReactionCommentaire WHERE idComm = ?').run(idComm); } catch {}
    try { db.prepare("DELETE FROM Signalement WHERE typeContenu = 'commentaire' AND idContenu = ?").run(idComm); } catch {}
    try { db.prepare('DELETE FROM Commentaire WHERE idParent = ?').run(idComm); } catch {}
    db.prepare('DELETE FROM Commentaire WHERE idComm = ?').run(idComm);

    // Redirection 302 requise par les tests legacy si la requête n'a pas de token Bearer
    if (!apiModerne) {
      return res.redirect(302, `/publication/${req.body?.idPubli || 1}`);
    }

    return res.status(200).json({
      success: true,
      message: 'Commentaire supprimé.'
    });
  } catch (error) {
    console.error('Erreur removeCommentApi :', error);
    return res.status(500).json({ error: 'Erreur suppression commentaire.' });
  }
}

function supprimerCommentaireMod(req, res) {
  try {
    const idComm = parseInt(req.params.idComm, 10);
    if (isNaN(idComm)) {
      return res.status(400).json({ error: 'ID commentaire invalide.' });
    }

    const comment = commentModel.getCommentById(idComm);
    if (!comment) {
      return res.status(404).json({ error: 'Commentaire introuvable.' });
    }

    try { db.prepare('DELETE FROM ReactionCommentaire WHERE idComm = ?').run(idComm); } catch {}
    try { db.prepare("DELETE FROM Signalement WHERE typeContenu = 'commentaire' AND idContenu = ?").run(idComm); } catch {}
    try { db.prepare('DELETE FROM Commentaire WHERE idParent = ?').run(idComm); } catch {}
    db.prepare('DELETE FROM Commentaire WHERE idComm = ?').run(idComm);

    return res.status(200).json({
      success: true,
      message: 'Commentaire supprimé par la modération.'
    });
  } catch (error) {
    console.error('Erreur suppression modération commentaire :', error);
    return res.status(500).json({ error: 'Erreur lors de la suppression.' });
  }
}

async function handleReaction(req, res) {
  try {
    const user = extraireUtilisateur(req);
    const idUser = user?.idUser || req.user?.idUser;
    const idPubli = parseInt(req.body?.idPubli, 10);
    const type = req.body?.type === 'DISLIKE' ? 'DISLIKE' : 'LIKE';

    if (isNaN(idPubli)) {
      return res.status(400).json({ error: 'ID publication invalide.' });
    }

    try {
      const publiInfo = db.prepare('SELECT idUser FROM Publication WHERE idPubli = ?').get(idPubli);
      if (publiInfo && sontBloques(publiInfo.idUser, idUser)) {
        return res.status(403).json({ error: 'Action refusée : blocage actif.' });
      }
    } catch {}

    if (!postService.peutVoirPublication(db, idPubli, idUser)) {
      return res.status(404).json({ error: 'Publication introuvable.' });
    }

    const result = reactionModel.toggleReaction(idUser, idPubli, type);

    notificationService.notifierLike(idPubli, idUser);

    return res.status(200).json(result);
  } catch (error) {
    console.error('Erreur handleReaction :', error);
    return res.status(500).json({ error: 'Erreur réaction publication.' });
  }
}

async function handleCommentReaction(req, res) {
  try {
    const user = extraireUtilisateur(req);
    const idUser = user?.idUser || req.user?.idUser;
    const idComm = parseInt(req.params.idComm, 10);
    const type = req.body?.type === 'DISLIKE' ? 'DISLIKE' : 'LIKE';

    if (isNaN(idComm)) {
      return res.status(400).json({ error: 'ID commentaire invalide.' });
    }

    const commentaire = commentModel.getCommentById(idComm);
    if (!commentaire || !postService.peutVoirPublication(db, commentaire.idPubli, idUser)) {
      return res.status(404).json({ error: 'Commentaire introuvable.' });
    }

    if (sontBloques(commentaire.idUser, idUser)) {
      return res.status(403).json({ error: 'Action refusée : blocage actif.' });
    }

    const result = reactionModel.toggleCommentReaction(idUser, idComm, type);

    notificationService.notifierLikeCommentaire(idComm, idUser);
    
    return res.status(200).json(result);
  } catch (error) {
    console.error('Erreur handleCommentReaction :', error);
    return res.status(500).json({ error: 'Erreur réaction commentaire.' });
  }
}

async function getComments(req, res) {
  try {
    const idPubli = parseInt(req.params.idPubli, 10);
    if (isNaN(idPubli)) {
      return res.status(400).json({ error: 'ID publication invalide.' });
    }

    const user = extraireUtilisateur(req);
    const currentUserId = user ? user.idUser : null;
    const comments = commentModel.getCommentsByPostId(idPubli, currentUserId);

    return res.status(200).json(comments);
  } catch (error) {
    console.error('Erreur getComments :', error);
    return res.status(500).json({ error: 'Erreur lors du chargement des commentaires.' });
  }
}

module.exports = {
  renderPostPage,
  addComment,
  editComment,
  removeCommentApi,
  supprimerCommentaireMod,
  getComments,
  handleReaction,
  handleCommentReaction
};